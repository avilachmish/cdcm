import org.openwsman.OpenWSMan;

public class loading_sharedlib {

  public static void main(String argv[]) {
	  System.out.println(OpenWSMan.class.getName() + " loaded");
  }
}
