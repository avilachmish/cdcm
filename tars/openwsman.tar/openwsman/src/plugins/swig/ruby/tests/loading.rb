# load openwsmanplugin.rb

$:.unshift "../../../../../build/bindings/ruby"
require 'openwsmanplugin'
